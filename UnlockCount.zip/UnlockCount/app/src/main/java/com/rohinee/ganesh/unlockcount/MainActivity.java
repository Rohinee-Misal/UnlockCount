package com.rohinee.ganesh.unlockcount;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import static android.app.Service.START_STICKY;

public class MainActivity extends AppCompatActivity {
//    private LockScreenStateReceiver mLockScreenStateReceiver;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    static int count = 0;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.textview);

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        int restoredText = prefs.getInt("count", 0);
        if (restoredText != 0) {
            count = restoredText; //0 is the default value.
            Log.i("count 1",""+count);
            textView.setText(""+restoredText);
            Log.i("count 2",""+restoredText);
        }

        startService(new Intent(this, HelloService.class));

   /*     mLockScreenStateReceiver = new LockScreenStateReceiver();
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);

        registerReceiver(mLockScreenStateReceiver, filter);*/

    }

/*
    public class LockScreenStateReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                // screen is turn off
                //("Screen locked");
            } else {
                //Handle resuming events if user is present/screen is unlocked
                count++;
                Log.i("count 3",""+count);
                textView.setText(""+count);
                Log.i("count 4",""+count);
                SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                editor.putInt("count", count);
                Log.i("count 5",""+count);
                //editor.apply();
                editor.commit();
                Log.i("count 6",""+count);
                //("Screen unlocked");
            }
        }
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(mLockScreenStateReceiver);
        super.onDestroy();
    }*/
}
